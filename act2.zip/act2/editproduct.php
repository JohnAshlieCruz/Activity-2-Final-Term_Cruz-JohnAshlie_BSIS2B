<?php
    require_once "config.php";

    if($_SESSION['role'] === '' || $_SESSION['user_id'] === ''){
        header('location: index.php');
    }


    $productid = $_GET['productid'];

    $fetchproduct = mysqli_query($conn, "SELECT * FROM products WHERE id = '$productid'");

    if(mysqli_num_rows($fetchproduct) === 0){
        echo "
            <script>
            alert('No product found with that ID!');

            window.location.href='products.php';
            </script>
        ";
    }

    $product = mysqli_fetch_assoc($fetchproduct);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <style>
    *{
        box-sizing: border-box;
    }
    body{
        margin: 0;
        padding: 32px;
        min-height:,100vh;
        background: linear-gradient(135deg,#f5fbff 0%,#fffaf0 55%,#fff7f4 100%);
        color: #252a35; 
        font-family: 'Inter', sans-serif;
    }
    h3{
        color: #253B57;
        font-weight: 800;
        font-size: clamp(27px,4vw,38px);
        letter-spacing: -.6px
    }
    form{
        display: flex;
        flex-wrap: wrap;
        align-items: flex-end;
        gap: 18px
    }
    form .field{
        display: flex;
        flex-direction: column;
        gap: 7px;
        min-width: 180px;
        flex: 1;
    }
    label{
        color: #354052;
        font-size: 15px;
        font-weight: 700;
    }
    input[type=text],input[type=number],input[type=password],input[type=url],textarea{
        width: 100%;
        padding: 12px 14px;
        border: 1px solid #DCE2EA;
        border-radius: 9px;
        background: #FFFFFF;
        color: #252A35;
        font: 14px 'Inter', sans-serif;
    }
    textarea{
        min-height: 110px;
        resize: vertical;
    }
    input:focus,textarea:focus{
        outline: none;
        border-color: #A9CDEB;
        box-shadow: 0 0 0 3px rgba(169,205,235,.22)
    }
    button,input[type=submit]{
        padding: 11px 16px;
        border: 0;
        border-radius: 9px;
        background: #F5D76E;
        color: #253B57; 
        font: 800 13px 'Inter', sans-serif;
        cursor:pointer
    }
    button:hover,input[type=submit]:hover{
        background: #EBC84F
    }
    table{
        width: 100%;
        min-width 680px;
        border-collapse: separate;
        border-spacing: 0;
        border: 1px solid #E5EAF0;
        border-radius: 12px;
        overflow: hidden;
        background: #FFFFFF;
    }
    th{
        padding: 14px 12px;
        background: #EAF3FB;
        color:  #253B57;
        text-align: left;
        font-size: 12px;
        font-weight: 800;
        border-bottom: 1px solid #DCE7F1;
    }
    td{
        padding: 13px 12px;
        color: #4B5565;
        font-size: 13px;
        text-align: left;
        border-bottom: 1px solid #EEF1F5;
    }
    tbody tr:hover{
        background: #FFFCF2;
    }
    tr:last-child td{
        border-bottom: 0;
    }
    form div{
        display: flex;
        flex-direction: column;
        gap: 5px;
    }
    form{
        display: flex;
        flex-direction: row;
        gap: 20px;
    }
    </style>
</head>
<body>
    <h3>Edit Product ID <?php echo $product['id'];?></h3>
            <br>
            <form action="" method="post">
                <div>
                    <div>
                        <label for="">Product Name:</label>
                        <input type="text" name="product_name" id="" required value='<?php echo $product['name'];?>'>
                    </div>
                    <br>
                    <div>
                        <label for="">Description:</label>
                        <textarea name="description" id="" cols="50" rows="5" required><?php echo $product['description'];?></textarea>
                    </div>
                </div>
                <div>
                    <div>
                        <label for="">Quantity:</label>
                        <input type="number" name="quantity" id="" required value='<?php echo $product['quantity'];?>'>
                    </div>
                    <br>
                    <div>
                        <label for="">Price:</label>
                        <input type="number" name="price" id="" required value='<?php echo $product['price'];?>'>
                    </div>
                </div>
                <div>
                    <div>
                        <label>Product image URL</label>
                        <input type="url" name="image_url" value="<?=h($product['image_url']??'')?>" placeholder="https://example.com/product.jpg">
                    </div>
                    <br>
                    <div>
                        <input type="submit" value="Save Product" name="savebtn">
                    </div>
                </div>
            </form>
</body>
</html>

<?php

    if(isset($_POST['savebtn'])){
        $name = $_POST['product_name'];
        $desc = $_POST['description'];
        $q = $_POST['quantity'];
        $price = $_POST['price'];

        $updatequery = "UPDATE products SET name='$name', description='$desc', quantity='$q', price='$price' WHERE id='$productid'";

        $updatefunc = mysqli_query($conn, $updatequery);

        if($updatefunc){
            echo "
                <script>
                    alert('Product saved successfully!');

                    window.location.href='products.php';
                </script>
            ";
        }
        else{
            echo "
                <script>
                    alert('Something went wrong. Please try again later.');

                    window.location.href='products.php';
                </script>
            ";
        }
    }

?>