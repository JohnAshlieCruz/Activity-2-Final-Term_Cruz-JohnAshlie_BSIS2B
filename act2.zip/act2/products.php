<?php
require_once "config.php";

$isAdmin = (($_SESSION['role'] ?? '') === 'admin');
$userId = (int)$_SESSION['user_id'];

$columnCheck = $conn->query("SHOW COLUMNS FROM products LIKE 'image_url'");
if ($columnCheck && $columnCheck->num_rows === 0) {
    $conn->query("ALTER TABLE products ADD image_url VARCHAR(500) NULL AFTER price");
}

$conn->query("CREATE TABLE IF NOT EXISTS saved_products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_saved_product (user_id, product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$conn->query("CREATE TABLE IF NOT EXISTS product_orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    total_price DECIMAL(10,2) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $productId = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);

    if ($action === 'add_product' && $isAdmin) {
        $name = trim($_POST['product_name'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);
        $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
        $imageUrl = trim($_POST['image_url'] ?? '');
        if ($imageUrl !== '' && !filter_var($imageUrl, FILTER_VALIDATE_URL)) $imageUrl = '';
        if ($name !== '' && $desc !== '' && $quantity !== false && $quantity !== null && $quantity >= 0 && $price !== false && $price !== null && $price >= 0) {
            $stmt = $conn->prepare("INSERT INTO products (name, description, quantity, price, image_url, created_by) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->bind_param('ssidsi', $name, $desc, $quantity, $price, $imageUrl, $userId);
            $stmt->execute(); $stmt->close();
            header('Location: products.php?added=1'); exit;
        } else { $error = 'Please enter valid product details.'; }
    } elseif ($action === 'save' && $productId) {
        $stmt = $conn->prepare("SELECT id FROM products WHERE id=?");
        $stmt->bind_param('i', $productId); $stmt->execute(); $exists = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($exists) {
            $stmt = $conn->prepare("INSERT IGNORE INTO saved_products (user_id, product_id) VALUES (?, ?)");
            $stmt->bind_param('ii', $userId, $productId); $stmt->execute(); $stmt->close();
            header('Location: products.php?saved=1'); exit;
        }
    } elseif ($action === 'unsave' && $productId) {
        $stmt = $conn->prepare("DELETE FROM saved_products WHERE user_id=? AND product_id=?");
        $stmt->bind_param('ii', $userId, $productId); $stmt->execute(); $stmt->close();
        header('Location: products.php?unsaved=1'); exit;
    } elseif ($action === 'order' && $productId && !$isAdmin) {
        $stmt = $conn->prepare("SELECT name, price, quantity FROM products WHERE id=?");
        $stmt->bind_param('i', $productId); $stmt->execute(); $productToOrder = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($productToOrder && (int)$productToOrder['quantity'] > 0) {
            $conn->begin_transaction();
            try {
                $qty = 1; $total = (float)$productToOrder['price'];
                $stmt = $conn->prepare("INSERT INTO product_orders (user_id, product_id, quantity, total_price) VALUES (?, ?, ?, ?)");
                $stmt->bind_param('iiid', $userId, $productId, $qty, $total); $stmt->execute(); $stmt->close();
                $stmt = $conn->prepare("UPDATE products SET quantity = quantity - 1 WHERE id=? AND quantity > 0");
                $stmt->bind_param('i', $productId); $stmt->execute();
                if ($stmt->affected_rows !== 1) throw new Exception('This item is no longer available.');
                $stmt->close(); $conn->commit();
                header('Location: products.php?ordered=1'); exit;
            } catch (Throwable $e) { $conn->rollback(); $error = 'Sorry, this item is no longer available.'; }
        } else { $error = 'Sorry, this item is currently out of stock.'; }
    }
}

$products = [];
$result = $conn->query("SELECT * FROM products ORDER BY created_at DESC, id DESC");
while ($row = $result->fetch_assoc()) $products[] = $row;
$savedIds = [];
if (!$isAdmin) {
    $stmt = $conn->prepare("SELECT product_id FROM saved_products WHERE user_id=?");
    $stmt->bind_param('i', $userId); $stmt->execute(); $savedResult = $stmt->get_result();
    while ($saved = $savedResult->fetch_assoc()) $savedIds[] = (int)$saved['product_id'];
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAWrfect | Pet Essentials</title>
    <style>
        *{box-sizing:border-box}
        body{
            margin: 0;
            padding: 32px;
            background: linear-gradient(135deg,#f5fbff 0%,#fffaf0 55%,#fff7f4 100%);
            font-family: 'Inter', sans-serif;
            color: #252a35;
            min-height: 100vh;
        }
        .nav{
            max-width: 1200px;
            margin: 0 auto 28px;
            padding: 16px 22px;
            display:flex;
            align-items:center;
            gap: 10px;
            flex-wrap: wrap;
            flex-direction: row;
            background: #FFFFFF;
            border: 1px solid #E9EDF3;
            border-radius:14px;
            box-shadow: 0 5px 20px rgba(37,42,53,0.04);
        }
        .nav:before{
            content: "PAWrfect";
            color: #253B57;
            font-size: 20px;
            font-weight: 800;
            letter-spacing: -0.8px;
            margin-right: auto;
        }
        .nav a {
            display: inline-block;
            padding: 9px 13px;
            border-radius: 8px;
            color: #426F9E;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            transition: background .2s ease, color .2s ease;
        }
        .nav a:hover{
            background: #FFF6D8;
            color: #253B57;
        }
        .main{
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
            background: #FFFFFF;
            border: 1px solid #E9EDF3;
            border-radius: 18px;
            box-shadow: 0 10px 30px rgba(37,42,53,0.045);
            overflow-x: auto;
        }
        .hero{
            padding: 30px 34px;
            margin-bottom: 24px;
            border-radius: 24px;
            background: linear-gradient(110deg,#e5f4fd,#fff1c8);
            border: 1px solid #E9EDF3;
            position: relative;
            overflow: hidden;
        }
        .eyebrow{
            font-size: 12px;
            font-weight: 900;
            letter-spacing: 1.5px;
            color: #6689a4;
            text-transform:uppercase;
        }
        .hero h1{
            margin: 7px 0 5px;
            font-size: clamp(27px,4vw,38px);
            line-height:1.15;
            color: #253B57;
            font-weight: 900;
        }
        .hero p{
            margin: 0;
            color: #6689a4;
            font-weight: 700;
        }
        .notice{
            padding: 12px 16px;
            margin: 0 0 18px;
            border-radius: 13px;
            background: #eaf8ef;
            color: #36744b;
            font-weight: 800;
        }
        .error{
            background: #fff0ed;
            color: #a34f43;
        }
        .section-head{
            display: flex;
            align-items: end;
            justify-content: space-between;
            gap: 12px;
            margin: 26px 2px 16px;
        }
        .section-head h2{
            margin: 0;
            color: #6689a4;
            font-size: 23px;
            font-weight: 900;
        }
        .section-head p{
            margin: 3px 0 0;
            color: #7A8494;
            font-size: 13px; 
            font-weight: 700;
        }
        .product-grid{
            display: grid;
            grid-template-columns: repeat(auto-fill,minmax(230px,1fr));
            gap: 20px;
        }
        .product-card{
            background: #FFFFFF;
            border: 1px solid #E9EDF3;
            border-radius: 21px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(37,42,53,0.04);
            transition: transform .2s,box-shadow .2s;
        } 
        .product-card:hover{
            transform: translateY(-4px);
            box-shadow: 0 15px 30px rgba(48,76,101,.11);
        }
        .product-image{
            height: 190px;
            background: linear-gradient(135deg,#e5f4fc,#fff0c9);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }
        .product-image img{
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .image-placeholder{
            font-size: 65px;
            filter: drop-shadow(0 5px 4px rgba(70,90,110,.12));
        }
        .stock-tag{
            position: absolute;
            top: 13px;
            left: 13px;
            padding: 6px 10px;
            background: rgba(255,255,255,.92);
            border-radius: 30px;
            color: #252a35;
            font-size: 11px; 
            font-weight: 900;
        }
        .product-info{
            padding: 17px;
        }
        .product-info h3{
            margin: 0 0 6px;
            color: #252a35;
            font-size: 18px;
            font-weight: 900;
        }
        .description{
            height: 42px; 
            overflow: hidden;
            color: #8392a0;
            font-size: 12px;
            line-height: 1.5;
            font-weight:700;
        }
        .price-row{
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin: 13px 0 14px;
        }
        .price{
            font-size: 20px;
            font-weight: 900;
            color: #252a35;
        }
        .quantity{
            font-size: 11px;
            color: #8392a0;
            font-weight: 800;
        }
        .actions{
            display: flex;
            gap: 8px;
        }
        .btn{
            border: 0;
            border-radius: 12px;
            padding: 10px 12px;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            transition:.2s;
        }
        .btn-order{
            background: #ffe69a;
            color: #695522;
            flex: 1;
        }
        .btn-order:hover{
            background: #ffdc70;
        }
        .btn-save{
            background: #dff0fb;
            color: #416b89;
            min-width: 43px;
        }
        .btn-save:hover{
            background: #b9def3;
        }
        .btn:disabled{
            opacity: .5;
            cursor: not-allowed;
        }
        .admin-panel{
            background: #FFFFFF;
            padding: 22px;
            border: 1px solid #E9EDF3;
            border-radius: 20px;
            box-shadow: 0 5px 20px rgba(37,42,53,0.04);
            margin-bottom: 22px;
        }
        .admin-panel h2{
            margin: 0 0 15px;
            color: #252a35;
        }
        .admin-form{
            display: grid;
            grid-template-columns: repeat(2,minmax(0,1fr));
            gap: 13px;
        }
        .field{
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .field.full{
            grid-column: 1/-1
        }
        label{
            font-size: 12px;
            font-weight :900; 
            color: #5c7185;
        }
        input,textarea{
            width: 100%; 
            padding: 11px 13px;
            border: 1px solid #dfe8ee;
            border-radius: 11px;
            background: #fbfdff;
            color: #34465a;
        }
        input:focus,textarea:focus{
            outline: 0;
            border-color: #a9d2eb;
            box-shadow:0 0 0 3px #e7f4fb;
        }
        textarea{
            min-height: 75px;
            resize: vertical;
        }
        .add-btn{
            grid-column: 1/-1;
            justify-self: start;
            background: #29445f;
            color: #fff; 
            padding: 11px 18px;
        }
        .add-btn:hover{
            background: #3b6385;
        }
        .admin-table-wrap{
            overflow-x: auto;
            background: #FFFFFF;
            border: 1px solid #E9EDF3;
            border-radius: 17px;
        }
        .admin-table{
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }
        .admin-table th,.admin-table td{
            padding: 12px 14px;
            text-align: left;
            border-bottom: 1px solid #edf1f4;
            font-size: 12px;
        }
        .admin-table th{
            background: #edf7fc;
            color: #252a35;
            font-weight: 900;
        }
        .admin-table td{
            color: #617589;
        }
        .admin-table tr:last-child td{
            border: 0;
        }
        .admin-table a{
            color: #47799a;
            font-weight: 900;
            text-decoration: none;
            margin-right: 10px;
        }
        .empty{
            padding: 40px;
            text-align: center;
            background: #FFFFFF;
            border: 1px dashed #cbdde9;
            border-radius: 18px;
            color: #8395a5;
            font-weight: 800;
        }
        .empty span{
            display: block;
            font-size: 42px;
            margin-bottom: 8px;
        }
    </style>
</head>
<body>
    <div class="nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php">Products</a>
        <?php if($isAdmin): ?>
        <a href="users.php">User Management</a>
        <?php endif; ?>
        <a href="logout.php">Logout</a>
    </div>
    <main class="main">
        <section class="hero">
            <div class="eyebrow">A little something for your furry friend</div>
            <h1><?= $isAdmin ? 'Pet Essentials Inventory' : 'Happy pets, happy hearts!' ?></h1>
            <p><?= $isAdmin ? 'Manage your PAWrfect products and keep the shelves stocked.' : 'Find your pet’s new favorite things, all in one cozy place. 🐾' ?></p>
        </section>
        <?php if($error): ?><div class="notice error">
            <?=h($error)?></div><?php endif; ?>
        <?php if(isset($_GET['added'])): ?>
            <div class="notice">✨ Product added successfully!</div>
            <?php endif; ?>
        <?php if(isset($_GET['saved'])): ?>
            <div class="notice">💛 Added to your saved favorites!</div>
            <?php endif; ?>
        <?php if(isset($_GET['unsaved'])): ?>
            <div class="notice">Product removed from your saved list.</div>
            <?php endif; ?>
        <?php if(isset($_GET['ordered'])): ?>
            <div class="notice">🎉 Your order has been placed! It is now marked as pending.</div>
            <?php endif; ?>
        <?php if($isAdmin): ?>
        <section class="admin-panel">
            <h2>＋ Add a Pet Essential</h2>
            <form class="admin-form" method="post">
                <input type="hidden" name="action" value="add_product">
                <div class="field">
                    <label>Product name</label>
                    <input type="text" name="product_name" placeholder="e.g. Fluffy pet shampoo" required>
                </div>
                <div class="field">
                    <label>Price (₱)</label>
                    <input type="number" name="price" min="0" step="0.01" placeholder="199.00" required>
                </div>
                <div class="field">
                    <label>Available quantity</label>
                    <input type="number" name="quantity" min="0" placeholder="10" required>
                </div>
                <div class="field">
                    <label>Product image URL</label>
                    <input type="url" name="image_url" placeholder="https://example.com/product.jpg">
                </div>
                <div class="field full">
                    <label>Description</label>
                    <textarea name="description" placeholder="Tell customers what makes this product special..." required>
                    </textarea>
                </div>
                <button class="btn add-btn" type="submit">Add Product</button>
            </form>
        </section>
        <?php endif; ?>
        <div class="section-head"><div>
            <h2><?= $isAdmin ? 'Product Preview' : 'Shop Pet Essentials' ?></h2>
            <p><?=count($products)?> adorable find<?=count($products)===1?'':'s'?> for your pets</p>
        </div>
    </div>
    <?php if(!$products): ?>
        <div class="empty"><span>🐾</span>No products yet. Check back soon!</div>
        <?php else: ?>
            <div class="product-grid">
                <?php foreach($products as $product): $pid=(int)$product['id']; $isSaved=in_array($pid,$savedIds,true); $img=trim($product['image_url']??''); $validImg=$img!=='' && filter_var($img,FILTER_VALIDATE_URL); ?>
                <article class="product-card">
                    <div class="product-image">
                        <?php if($validImg): ?>
                            <img src="<?=h($img)?>" alt="<?=h($product['name'])?>" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='block';">
                            <span class="image-placeholder" style="display:none">🐾</span>
                        <?php else: ?>
                            <span class="image-placeholder">🐾</span>
                        <?php endif; ?>
                            <span class="stock-tag"><?=((int)$product['quantity']>0)?'In stock · '.(int)$product['quantity']:'Sold out'?></span>
                    </div>
                    <div class="product-info">
                        <h3><?=h($product['name'])?></h3>
                    <div class="description">
                        <?=h($product['description'])?>
                    </div>
                    <div class="price-row">
                        <span class="price">₱<?=number_format((float)$product['price'],2)?></span>
                        <span class="quantity"><?=((int)$product['quantity']>0)?'Ready to love':'Unavailable'?></span>
                    </div>
                    <?php if($isAdmin): ?>
                        <div class="actions">
                            <a class="btn btn-save" style="flex:1" href="editproduct.php?productid=<?=$pid?>">✎ Edit</a>
                            <a class="btn btn-order" href="deleteproduct.php?productid=<?=$pid?>" onclick="return confirm('Delete this product?')">Delete</a>
                        </div>
                    <?php else: ?>
                        <div class="actions">
                            <form method="post" style="flex:1;display:flex">
                                <input type="hidden" name="action" value="order">
                                <input type="hidden" name="product_id" value="<?=$pid?>">
                                <button class="btn btn-order" type="submit" style="width:100%" <?=((int)$product['quantity']<1)?'disabled':''?>>🛒 Order</button>
                            </form>
                            <form method="post">
                                <input type="hidden" name="action" value="<?=$isSaved?'unsave':'save'?>">
                                <input type="hidden" name="product_id" value="<?=$pid?>">
                                <button class="btn btn-save" type="submit" title="<?=$isSaved?'Remove from saved':'Save product'?>"><?=$isSaved?'♥':'♡'?></button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
                </article>
                <?php endforeach; ?>
            </div><?php endif; ?>
            <?php if($isAdmin): ?>
                <div class="section-head">
                    <div><h2>Inventory Management</h2>
                    <p>Edit or remove products from your shop</p></div>
                </div>
                <div class="admin-table-wrap">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Date Added</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($products as $product): ?>
                                <tr>
                                    <td><?=h($product['id'])?></td>
                                    <td><?=h($product['name'])?></td>
                                    <td><?=h($product['quantity'])?></td>
                                    <td>₱<?=number_format((float)$product['price'],2)?></td>
                                    <td><?=h($product['created_at'])?></td>
                                    <td><a href="editproduct.php?productid=<?=h($product['id'])?>">Edit</a>
                                    <a href="deleteproduct.php?productid=<?=h($product['id'])?>" onclick="return confirm('Delete this product?')">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
    </main>

    
</body>
</html>