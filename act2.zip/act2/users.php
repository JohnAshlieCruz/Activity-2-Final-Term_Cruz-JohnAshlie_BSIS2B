<?php
    require_once "config.php";

    if($_SESSION['role'] === '' || $_SESSION['user_id'] === ''){
        header('location: index.php');
    }

    if($_SESSION['role'] !== 'admin'){
        header("location: dashboard.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management</title>
    <style>
        *{box-sizing:border-box}
        body{
            margin: 0;
            padding: 32px;
            background: linear-gradient(135deg,#f5fbff 0%,#fffaf0 55%,#fff7f4 100%);
            font-family: 'Inter', sans-serif;
            color: #252a35;
            min-height: 100vh;
        }
        .nav{
            max-width: 1200px;
            margin: 0 auto 28px;
            padding: 16px 22px;
            display:flex;
            align-items:center;
            gap: 10px;
            flex-wrap: wrap;
            flex-direction: row;
            background: #FFFFFF;
            border: 1px solid #E9EDF3;
            border-radius:14px;
            box-shadow: 0 5px 20px rgba(37,42,53,0.04);
        }
        .nav:before{
            content: "PAWrfect";
            color: #253B57;
            font-size: 20px;
            font-weight: 800;
            letter-spacing: -0.8px;
            margin-right: auto;
        }
        .nav a {
            display: inline-block;
            padding: 9px 13px;
            border-radius: 8px;
            color: #426F9E;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            transition: background .2s ease, color .2s ease;
        }
        .nav a:hover{
            background: #FFF6D8;
            color: #253B57;
        }
        .main{
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
            background: #FFFFFF;
            border: 1px solid #E9EDF3;
            border-radius: 18px;
            box-shadow: 0 10px 30px rgba(37,42,53,0.045);
            overflow-x: auto;
        }
        h1{
            color: #253B57;
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -.6px;
        }
        p{
            color: #7A8494;
            font-size: 13px;
            font-weight: 500;
        }
        table{
            width: 100%; 
            min-width: 680px;
            border-collapse: separate;
            border-spacing: 0;
            border: 1px solid #E5EAF0;
            border-radius: 12px;
            overflow: hidden;
            background: #FFFFFF;
        }
        th{
            padding: 14px 12px;
            background: #EAF3FB;
            color: #253B57;
            text-align: left;
            font-size: 12px;
            font-weight: 800;
            border-bottom: 1px solid #DCE7F1;
        }
        td{
            padding: 13px 12px;
            color: #4B5565;
            font-size: 13px;
            text-align: left;
            border-bottom: 1px solid #EEF1F5;
        }
        tbody tr:hover{
            background: #FFFCF2;
        }
        tr:last-child td{
            border-bottom: 0;
        }
        button{
            padding: 9px 13px;
            border: 0;
            border-radius: 9px;
            background: #F5D76E;
            color: #253B57;
            font: 800 12px 'Inter',sans-serif;
            cursor: pointer;
        }
        button:hover{
            background: #EBC84F;
        }
    </style>
</head>
<body>
    <div class="nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php">Products</a>
        <?php if ($_SESSION['role'] === 'admin'):?>
        <a href="users.php">User Management</a>
        <?php endif; ?>
        <a href="logout.php">Logout</a>
    </div>
    <br>
    <div class="main">
        <h1>PAWrfect User Management</h1>
        <p>Approve new accounts or temporarily disable approved user accounts.</p>
        <br>
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Status</th>
                    <th>Role</th>
                    <th>Date Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $fetchquery = "SELECT * FROM users";

                    $fetch = mysqli_query($conn, $fetchquery);

                    if(mysqli_num_rows($fetch)>0){
                        while($user = mysqli_fetch_assoc($fetch)){
                    ?>
                        <tr>
                            <td><?php echo $user['username'];?></td>
                            <td><?php echo $user['status'];?></td>
                            <td><?php echo $user['role'];?></td>
                            <td><?php echo $user['created_at'];?></td>
                            <td>
                                <?php if($user['status'] !== 'approved'):?>
                                <button onclick="window.location.href='approveuser.php?userid=<?php echo $user['id']; ?>'">Approve</button>
                                <?php elseif($user['status'] === 'approved'):?>
                                <button onclick="window.location.href='disableuser.php?userid=<?php echo $user['id']; ?>'">Disable</button>
                                <?php endif;?>
                            </td>
                        </tr>
                    <?php
                        }
                    }
                    else{
                        ?>
                        <tr>
                            <td colspan="5">No Users Found.</td>
                        </tr>
                        <?php
                    }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>