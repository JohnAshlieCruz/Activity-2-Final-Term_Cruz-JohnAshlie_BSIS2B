<?php
    require_once "config.php";

    if(!isset($_SESSION['user_id']) && !isset($_SESSION['username']) && !isset($_SESSION['role'])){
        header('location: index.php');
    }


    $totaluser = $conn->query("SELECT COUNT(*) AS total from users")->fetch_assoc()['total'];
    $totalpending = $conn->query("SELECT COUNT(*) AS total from users WHERE status = 'pending'")->fetch_assoc()['total'];
    $totalproducts = $conn->query("SELECT COUNT(*) AS total from products")->fetch_assoc()['total'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PAWrfect | Dashboard</title>
    <style>
        *{
            box-sizing: border-box;
        }
        body{
            margin: 0;
            padding: 32px;
            min-height: 100vh;
            background: linear-gradient(135deg,#f5fbff 0%,#fffaf0 55%,#fff7f4 100%);
            color: #252a35;
            font-family: 'Inter', sans-serif;
        }
        .nav {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            flex-direction: row;
            gap: 10px;
            padding: 16px 22px;
            margin: 0 auto 28px;
            max-width: 1200px;
            background: #FFFFFF;
            border: 1px solid #E9EDF3;
            border-radius: 14px;
            box-shadow: 0 5px 20px rgba(37,42,53,0.04);
        }
        .nav::before {
            content: "PAWrfect";
            color: #253B57;
            font-size: 20px;
            font-weight: 800;
            letter-spacing: -0.8px;
            margin-right: auto;
        }
        .nav a {
            display: inline-block;
            padding: 9px 13px;
            border-radius: 8px;
            color: #426F9E;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            transition: background .2s ease, color .2s ease;
        }
        .nav a:hover {
            background: #FFF6D8;
            color: #253B57;
        }
        .main {
            max-width: 1200px;
            margin: 0 auto;
            padding: 30px;
            background: #FFFFFF;
            border: 1px solid #E9EDF3;
            border-radius: 18px;
            box-shadow: 0 10px 30px rgba(37,42,53,0.045);
            overflow-x: auto;
        }
        h1, h2, h3 {
            color: #253B57;
            font-weight: 800;
            letter-spacing: -0.6px;
        }
        h1 { font-size: 28px; }
        h2 { font-size: 22px; }
        h3 { font-size: 18px; }
        p { color: #7A8494; }
        
        hr {
           border: 0;
           border-top: 1px solid #E9EDF3;
        }
        form {
           display: flex;
           flex-wrap: wrap;
           align-items: flex-end;
           gap: 18px;
        }
        form div {
           display: flex;
           flex-direction: column;
           gap: 7px;
        }
        label {
           color: #354052;
           font-size: 13px;
           font-weight: 700;
        }
        input[type="text"],
        input[type="number"],
        input[type="password"],
        textarea {
           width: 100%;
           min-width: 190px;
           padding: 12px 14px;
           border: 1px solid #DCE2EA;
           border-radius: 9px;
           background: #FFFFFF;
           color: #252A35;
           font-family: 'Inter', sans-serif;
           font-size: 14px;
           outline: none;
        }
        textarea {
           min-height: 110px;
           resize: vertical;
        }
        input:focus, textarea:focus {
           border-color: #A9CDEB;
           box-shadow: 0 0 0 3px rgba(169,205,235,.22);
        }
        input[type="submit"], button {
           padding: 11px 16px;
           border: 0;
           border-radius: 9px;
           background: #F5D76E;
           color: #253B57;
           font-family: 'Inter', sans-serif;
           font-size: 13px;
           font-weight: 800;
           cursor: pointer;
           transition: background .2s ease, transform .2s ease;
        }
        input[type="submit"]:hover, button:hover {
           background: #EBC84F;
           transform: translateY(-1px);
        }
        table {
           width: 100%;
           min-width: 680px;
           border-collapse: separate;
           border-spacing: 0;
           border: 1px solid #E5EAF0;
           border-radius: 12px;
           overflow: hidden;
           background: #FFFFFF;
        }
        th {
           padding: 14px 12px;
           background: #EAF3FB;
           color: #253B57;
           text-align: left;
           font-size: 12px;
           font-weight: 800;
           border-bottom: 1px solid #DCE7F1;
        }
        td {
           padding: 13px 12px;
           color: #4B5565;
           font-size: 13px;
           text-align: left;
           border-bottom: 1px solid #EEF1F5;
        }
        tr:last-child td { border-bottom: 0; }
        tbody tr:hover { background: #FFFCF2; }
        .cards {
           display: flex;
           flex-wrap: wrap;
           gap: 18px;
        }
        .card,
        .card[style] {
           flex: 1 1 210px;
           width: auto;
           min-height: 135px;
           padding: 22px;
           border: 1px solid #E9EDF3;
           border-radius: 15px;
           background: #FFFFFF !important;
           color: #253B57 !important;
           text-align: left;
           box-shadow: 0 6px 18px rgba(37,42,53,0.04);
        }
        .card h3 {
           color: #7A8494;
           font-size: 13px;
           margin-top: 0;
        }
        .card h2 {
           color: #253B57;
           font-size: 30px;
           margin-bottom: 0;
        }
    </style>
</head>
<body>
    <div class="nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="products.php">Products</a>
        <?php if ($_SESSION['role'] === 'admin'):?>
        <a href="users.php">User Management</a>
        <?php endif; ?>
        <a href="logout.php">Logout</a>
    </div>
    <br>
    <div class="main">
        <h1>Welcome to PAWrfect!</h1>
        <br>
        <div class="cards">
            <div class="card" style="background-color: blue;">
                <h3>Total of Users</h3>
                <h2><?php echo $totaluser; ?></h2>
            </div>
            <div class="card" style="background-color: orange;">
                <h3>Total of Not Approved Users</h3>
                <h2><?php echo $totalpending; ?></h2>
            </div>
            <div class="card" style="background-color: green;">
                <h3>Total of Products</h3>
                <h2><?php echo $totalproducts; ?></h2>
            </div>
        </div>
    </div>
</body>
</html>